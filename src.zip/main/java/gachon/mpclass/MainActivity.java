package gachon.mpclass;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

import gachon.mpclass.myapplication.MainActivity2;
import gachon.mpclass.myapplication.R;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;
    private int backPressed = 0;
    private home home;
    private Carlendar calendar;
    private profile profile;
    private gachon.mpclass.talk talk;
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("Users");
    private FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomnav1);
        firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser user = firebaseAuth.getCurrentUser();

        myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {

            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {

            }
        });

        //처음 화면
        getSupportFragmentManager().beginTransaction().add(R.id.main_frame, new home()).commit();
        //바텀 네비게이션뷰 안의 아이템 설정

        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                switch (menuItem.getItemId()) {
                    //item을 클릭시 id값을 가져와 FrameLayout에 fragment.xml띄우기
                    case R.id.home_fragment3:

                        /*getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, new home()).commit();*/
                        Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                        startActivity(intent);

                        break;
                    case R.id.calender_fragment1:
                        getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, new Carlendar()).commit();
                        break;
                    case R.id.profile_fragment4:
                        getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, new profile()).commit();
                        break;
                    case R.id.talk_fragment2:
                        getSupportFragmentManager().beginTransaction().replace(R.id.main_frame, new gachon.mpclass.talk()).commit();
                        break;

                }
                return true;
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (backPressed == 0) {
            setFrag(0);
            bottomNavigationView.getMenu().getItem(0).setChecked(true);
            backPressed++;
        } else finish();
    }

    private void setFrag(int n) {
        FragmentManager fm = getSupportFragmentManager();

        switch (n) {
            case 0:
                if (home == null) {
                    home = new home();
                    fm.beginTransaction().add(R.id.main_frame, home).commit();
                }
                if (home != null) fm.beginTransaction().show(home).commit();


                if (talk != null) fm.beginTransaction().hide(talk).commit();
                if (profile != null) fm.beginTransaction().hide(profile).commit();

                break;

        }
    }
}


