package gachon.mpclass.viewmodel;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.LocationManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import gachon.mpclass.dialog.NumberPickerDialog;
import gachon.mpclass.myapplication.ApiClient;
import gachon.mpclass.myapplication.ApiInterface;
import gachon.mpclass.myapplication.CategoryResult;
import gachon.mpclass.myapplication.Document;
import gachon.mpclass.myapplication.GpsTracker;
import gachon.mpclass.myapplication.GpsTracker_main;
import gachon.mpclass.myapplication.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class GpsTrackerMainViewModel {

    GpsTracker_main activity;
    public double x0, x1, x2, x3, y0, y1, y2, y3;
    public double centerx, centery;
    public String address;

    public TextView textview_address3;
    public TextView tvPeopleAmount;
    public AutoCompleteTextView et_addr0;
    public AutoCompleteTextView et_addr1;
    public AutoCompleteTextView et_addr2;

    public TextView textview_address;
    public TextView textview_address1;
    public TextView textview_address0;
    public TextView textview_address2;

    public LinearLayout linear_location_0;
    public LinearLayout linear_location_1;
    public LinearLayout linear_location_2;

    public AutoCompleteTextView autoCompleteTextView;

    public Button ShowLocationButton;
    public Button returnto;
    public Button ShowPeopleButton;

    private List<String> list;

    public GpsTrackerMainViewModel(GpsTracker_main activity) {
        this.activity = activity;
    }

    public void showInputLocation(int count) {
        hideInputAllLocation();
        switch (count) {
            case 1:
                break;
            case 2:
                linear_location_0.setVisibility(View.VISIBLE);
                break;
            case 3:
                linear_location_0.setVisibility(View.VISIBLE);
                linear_location_1.setVisibility(View.VISIBLE);
                break;
            case 4:
                linear_location_0.setVisibility(View.VISIBLE);
                linear_location_1.setVisibility(View.VISIBLE);
                linear_location_2.setVisibility(View.VISIBLE);
                break;
        }
    }

    public void hideInputAllLocation() {
        linear_location_0.setVisibility(View.GONE);
        linear_location_1.setVisibility(View.GONE);
        linear_location_2.setVisibility(View.GONE);
    }


    public void setSearchEditChangeListener(AutoCompleteTextView autoCompleteTextView) {
        autoCompleteTextView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
                Log.d("test", "beforeTextChanged charSequence.toString()" + charSequence.toString());
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                Log.d("test", "onTextChanged charSequence.toString()" + charSequence.toString());
                if (charSequence.length() >= 1) {
                    callSearchLocation(charSequence, autoCompleteTextView);
                } else {
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                Log.d("test", "afterTextChanged charSequence.toString()" + editable.toString());
            }
        });
    }

    public void callSearchLocation(CharSequence charSequence, AutoCompleteTextView autoCompleteTextView) {
        ApiInterface apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
        Call<CategoryResult> call = apiInterface.getSearchLocation(activity.getString(R.string.restapi_key), charSequence.toString(), 15);
        call.enqueue(new Callback<CategoryResult>() {
            @Override
            public void onResponse(Call<CategoryResult> call, Response<CategoryResult> response) {
                if (response.isSuccessful()) {
                    ArrayList<String> list = new ArrayList<>();
                    assert response.body() != null;
                    for (Document document : response.body().getDocuments()) {
                        //activity.locationAdapter.addItem(document);
                        list.add(document.getPlaceName());
                    }
                    setAutoCompleteTextView(list, autoCompleteTextView);
                }
            }

            @Override
            public void onFailure(Call<CategoryResult> call, Throwable t) {

            }

        });
    }

    public void setAutoCompleteTextView(ArrayList<String> list, AutoCompleteTextView autoCompleteTextView) {
        autoCompleteTextView.setAdapter(new ArrayAdapter<String>(activity,
                android.R.layout.simple_dropdown_item_1line, list));
    }

    public void etAddr2SetText() {
        Intent intent = new Intent(activity.getIntent());
        String temp = intent.getStringExtra("mSearchEdit");
        et_addr0.setText(temp);
        if(et_addr0.getText().toString().equals("") || et_addr0.getText().toString().equals("No Data")){
            showInputLocation(1);
            tvPeopleAmount.setText("1명");
        }else {
            showInputLocation(2);
            tvPeopleAmount.setText("2명");
        }
    }


    public boolean checkLocationServicesStatus() {
        LocationManager locationManager = (LocationManager) activity.getSystemService(activity.LOCATION_SERVICE);

        return locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)
                || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER);
    }

    public void Center() {
        double Area = 0.0;
        x0 -= 37;
        y0 -= 127;
        x1 -= 37;
        y1 -= 127;
        x2 -= 37;
        y2 -= 127;
        x3 -= 37;
        y3 -= 127;
        Area = 0.5 * ((x0 * y1 - x1 * y0) + (x1 * y2 - x2 * y1) + (x2 * y3 - x3 * y2));
        if (Area < 0)
            Area = -Area;
        centerx = (1 / (6 * Area)) * ((x0 + x1) * (x0 * y1 - x1 * y0) + (x1 + x2) * (x1 * y2 - x2 * y1) + (x2 + x3) * (x2 * y3 - x3 * y2));
        centery = (1 / (6 * Area)) * ((y0 + y1) * (x0 * y1 - x1 * y0) + (y1 + y2) * (x1 * y2 - x2 * y1) + (y2 + y3) * (x2 * y3 - x3 * y2));

        Log.e("HAN", "x0:    " + x0);
        Log.e("HAN", "x1:    " + x1);
        Log.e("HAN", "x2:    " + x2);
        Log.e("HAN", "x3:    " + x3);

        Log.e("HAN", "y0:    " + y0);
        Log.e("HAN", "y1:    " + y1);
        Log.e("HAN", "y2:    " + y2);
        Log.e("HAN", "y3:    " + y3);

        Log.e("HAN", "Area:    " + Area);
        Log.e("HAN", "( (x0+x1)*(x0*y1-x1*y0)+(x1+x2)*(x1*y2-x2*y1)+(x2+x3)*(x2*y3-x3*y2)  )    " + ((x0 + x1) * (x0 * y1 - x1 * y0) + (x1 + x2) * (x1 * y2 - x2 * y1) + (x2 + x3) * (x2 * y3 - x3 * y2)));
        Log.e("HAN", "( (y0+y1)*(x0*y1-x1*y0)+(y1+y2)*(x1*y2-x2*y1)+(y2+y3)*(x2*y3-x3*y2)  )   " + ((y0 + y1) * (x0 * y1 - x1 * y0) + (y1 + y2) * (x1 * y2 - x2 * y1) + (y2 + y3) * (x2 * y3 - x3 * y2)));

        Log.e("HAN", "centerx:    " + centerx);
        Log.e("HAN", "centery:    " + centery);

        if (centerx < 0)
            centerx = -1 * centerx;

        if (centery < 0)
            centery = -1 * centery;

        centerx += 37;
        centery += 127;
        address = getCurrentAddress(centerx, centery);
        textview_address3.setText(address);
    }

    public void checkRunTimePermission() {

        //런타임 퍼미션 처리
        // 1. 위치 퍼미션을 가지고 있는지 체크합니다.
        int hasFineLocationPermission = ContextCompat.checkSelfPermission(activity,
                Manifest.permission.ACCESS_FINE_LOCATION);
        int hasCoarseLocationPermission = ContextCompat.checkSelfPermission(activity,
                Manifest.permission.ACCESS_COARSE_LOCATION);


        if (hasFineLocationPermission == PackageManager.PERMISSION_GRANTED &&
                hasCoarseLocationPermission == PackageManager.PERMISSION_GRANTED) {

            // 2. 이미 퍼미션을 가지고 있다면
            // ( 안드로이드 6.0 이하 버전은 런타임 퍼미션이 필요없기 때문에 이미 허용된 걸로 인식합니다.)


            // 3.  위치 값을 가져올 수 있음


        } else {  //2. 퍼미션 요청을 허용한 적이 없다면 퍼미션 요청이 필요합니다. 2가지 경우(3-1, 4-1)가 있습니다.

            // 3-1. 사용자가 퍼미션 거부를 한 적이 있는 경우에는
            if (ActivityCompat.shouldShowRequestPermissionRationale(activity, activity.REQUIRED_PERMISSIONS[0])) {

                // 3-2. 요청을 진행하기 전에 사용자가에게 퍼미션이 필요한 이유를 설명해줄 필요가 있습니다.
                Toast.makeText(activity, "이 앱을 실행하려면 위치 접근 권한이 필요합니다.", Toast.LENGTH_LONG).show();
                // 3-3. 사용자게에 퍼미션 요청을 합니다. 요청 결과는 onRequestPermissionResult에서 수신됩니다.
                ActivityCompat.requestPermissions(activity, activity.REQUIRED_PERMISSIONS,
                        activity.PERMISSIONS_REQUEST_CODE);


            } else {
                // 4-1. 사용자가 퍼미션 거부를 한 적이 없는 경우에는 퍼미션 요청을 바로 합니다.
                // 요청 결과는 onRequestPermissionResult에서 수신됩니다.
                ActivityCompat.requestPermissions(activity, activity.REQUIRED_PERMISSIONS,
                        activity.PERMISSIONS_REQUEST_CODE);
            }

        }

    }

    public void checkPermission() {
        if (!checkLocationServicesStatus()) {
            showDialogForLocationServiceSetting();
        } else {
            checkRunTimePermission();
        }
    }

    //여기부터는 GPS 활성화를 위한 메소드들
    private void showDialogForLocationServiceSetting() {

        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("위치 서비스 비활성화");
        builder.setMessage("앱을 사용하기 위해서는 위치 서비스가 필요합니다.\n"
                + "위치 설정을 수정하실래요?");
        builder.setCancelable(true);
        builder.setPositiveButton("설정", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                Intent callGPSSettingIntent
                        = new Intent(android.provider.Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                activity.startActivityForResult(callGPSSettingIntent, activity.GPS_ENABLE_REQUEST_CODE);
            }
        });
        builder.setNegativeButton("취소", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int id) {
                dialog.cancel();
            }
        });
        builder.create().show();
    }

    public String getCurrentAddress(double latitude, double longitude) {

        //지오코더... GPS를 주소로 변환
        Geocoder geocoder = new Geocoder(activity, Locale.getDefault());

        List<Address> addresses;

        try {

            addresses = geocoder.getFromLocation(
                    latitude,
                    longitude,
                    7);
        } catch (IOException ioException) {
            //네트워크 문제
            Toast.makeText(activity, "지오코더 서비스 사용불가", Toast.LENGTH_LONG).show();
            return "지오코더 서비스 사용불가";
        } catch (IllegalArgumentException illegalArgumentException) {
            Toast.makeText(activity, "잘못된 GPS 좌표", Toast.LENGTH_LONG).show();
            return "잘못된 GPS 좌표";

        }


        if (addresses == null || addresses.size() == 0) {
            Toast.makeText(activity, "주소 미발견", Toast.LENGTH_LONG).show();
            return "주소 미발견";

        }

        Address address = addresses.get(0);
        return address.getAddressLine(0).toString() + "\n";

    }

    double sumX = 0;
    double sumY = 0;
    int peopleTempCount = 0;

    public void setSumX() {
        sumX = 0;
        peopleTempCount = 0;
        if (x0 != 0) {
            sumX += x0;
            peopleTempCount++;
        }
        if (x1 != 0 && linear_location_0.getVisibility() == View.VISIBLE) {
            sumX += x1;
            peopleTempCount++;
        }
        if (x2 != 0 && linear_location_1.getVisibility() == View.VISIBLE) {
            sumX += x2;
            peopleTempCount++;
        }
        if (x3 != 0 && linear_location_2.getVisibility() == View.VISIBLE) {
            sumX += x3;
            peopleTempCount++;
        }
    }

    public void setSumY() {
        sumY = 0;
        if (y0 != 0) {
            sumY += y0;
        }
        if (y1 != 0 && linear_location_0.getVisibility() == View.VISIBLE) {
            sumY += y1;
        }
        if (y2 != 0 && linear_location_1.getVisibility() == View.VISIBLE) {
            sumY += y2;
        }
        if (y3 != 0 && linear_location_2.getVisibility() == View.VISIBLE) {
            sumY += y3;
        }
    }

    public void Center2(int peopleCount) {
        setSumX();
        setSumY();
        if (peopleTempCount == peopleCount) {
            centerx = sumX / peopleTempCount;
            centery = sumY / peopleTempCount;
            address = getCurrentAddress(centerx, centery);
            textview_address3.setText(address);
        } else {
            Toast.makeText(activity, "입력된 주소와 설정 인원이 일치하지 않습니다.", Toast.LENGTH_LONG).show();
        }
    }

    public void setReturntoClick() {
        Intent intent = new Intent(activity.getIntent());
        returnto.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View view) {
                                            intent.putExtra("my_datax", centerx);
                                            intent.putExtra("my_datay", centery);
                                            activity.setResult(activity.RESULT_OK, intent);
                                            activity.finish();
                                        }
                                    }
        );
    }

    public void ShowPeopleClick() {
        ShowPeopleButton.setOnClickListener(view ->
                //min  max 값 조절로 인원 설정을  늘릴수있음. 현재는 1~4까지만 되도록설정
                NumberPickerDialog.showNumberPickerDialog(
                        value -> {
                            tvPeopleAmount.setText(value + "명");
                            showInputLocation(Integer.parseInt(value));
                        }
                        ,
                        activity.getSupportFragmentManager(),
                        1, 4, 1));
    }

    public void setShowLocationClick() {
        ShowLocationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View arg0) {
                int peopleCount = 1;
                if (!tvPeopleAmount.getText().toString().equals("")) {
                    peopleCount = Integer.parseInt(tvPeopleAmount.getText().toString().replace("명", ""));
                }

                activity.gpsTracker = new GpsTracker(activity);

                double latitude = activity.gpsTracker.getLatitude();
                double longitude = activity.gpsTracker.getLongitude();

                x0 = latitude;
                y0 = longitude;
                String address = getCurrentAddress(latitude, longitude);
                textview_address.setText(address);

                //Toast.makeText(activity, "현재위치 \n위도 " + latitude + "\n경도 " + longitude, Toast.LENGTH_LONG).show();

                //입력값
                List<Address> list0 = null;
                List<Address> list1 = null;
                List<Address> list2 = null;


                String str = et_addr0.getText().toString();
                try {
                    list0 = activity.geocoder.getFromLocationName(
                            str, // 지역 이름
                            10); // 읽을 개수
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("test", "입출력 오류 - 서버에서 주소변환시 에러발생");
                }

                if (list0 != null) {
                    if (list0.size() == 0) {
                        textview_address0.setText("해당되는 주소 정보는 없습니다");
                    } else {
                        x1 = list0.get(0).getLatitude();
                        y1 = list0.get(0).getLongitude();
                        address = getCurrentAddress(list0.get(0).getLatitude(), list0.get(0).getLongitude());
                        textview_address0.setText(address);
                    }
                }

                String str1 = et_addr1.getText().toString();
                try {
                    list1 = activity.geocoder.getFromLocationName(
                            str1, // 지역 이름
                            10); // 읽을 개수
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("test", "입출력 오류 - 서버에서 주소변환시 에러발생");
                }

                if (list1 != null) {
                    if (list1.size() == 0) {
                        textview_address1.setText("해당되는 주소 정보는 없습니다");
                    } else {
                        address = getCurrentAddress(list1.get(0).getLatitude(), list1.get(0).getLongitude());
                        textview_address1.setText(address);

                        x2 = list1.get(0).getLatitude();
                        y2 = list1.get(0).getLongitude();
                    }
                }

                String str2 = et_addr2.getText().toString();
                try {
                    list2 = activity.geocoder.getFromLocationName(
                            str2, // 지역 이름
                            10); // 읽을 개수
                } catch (IOException e) {
                    e.printStackTrace();
                    Log.e("test", "입출력 오류 - 서버에서 주소변환시 에러발생");
                }

                if (list2 != null) {
                    if (list2.size() == 0) {
                        textview_address2.setText("해당되는 주소 정보는 없습니다");
                    } else {
                        address = getCurrentAddress(list2.get(0).getLatitude(), list2.get(0).getLongitude());
                        textview_address2.setText(address);
                        x3 = list2.get(0).getLatitude();
                        y3 = list2.get(0).getLongitude();
                    }
                }

                Center2(peopleCount);
            }
        });
    }

    public void setView() {
        et_addr0 = activity.findViewById(R.id.et_text0);
        et_addr1 = activity.findViewById(R.id.et_text1);
        et_addr2 = activity.findViewById(R.id.et_text2);

        textview_address3 = (TextView) activity.findViewById(R.id.textview3);
        tvPeopleAmount = (TextView) activity.findViewById(R.id.textview4);

        textview_address = (TextView) activity.findViewById(R.id.my_textview);
        textview_address1 = (TextView) activity.findViewById(R.id.textview1);
        textview_address0 = (TextView) activity.findViewById(R.id.textview0);
        textview_address2 = (TextView) activity.findViewById(R.id.textview2);

        ShowPeopleButton = (Button) activity.findViewById(R.id.btn_setting_people);
        ShowLocationButton = (Button) activity.findViewById(R.id.button);
        returnto = (Button) activity.findViewById(R.id.button2);

        linear_location_0 = (LinearLayout) activity.findViewById(R.id.linear_location_0);
        linear_location_1 = (LinearLayout) activity.findViewById(R.id.linear_location_1);
        linear_location_2 = (LinearLayout) activity.findViewById(R.id.linear_location_2);

        setSearchEditChangeListener(et_addr0);
        setSearchEditChangeListener(et_addr1);
        setSearchEditChangeListener(et_addr2);

    }


}
