package gachon.mpclass.viewmodel;

import android.content.Intent;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.view.animation.AnimationUtils;
import android.widget.Toast;

import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;

import net.daum.mf.map.api.MapView;

import gachon.mpclass.adapter.LocationAdapter;
import gachon.mpclass.myapplication.ApiClient;
import gachon.mpclass.myapplication.ApiInterface;
import gachon.mpclass.myapplication.CategoryResult;
import gachon.mpclass.myapplication.Document;
import gachon.mpclass.myapplication.GpsTracker_main;
import gachon.mpclass.myapplication.MainActivity2;
import gachon.mpclass.myapplication.R;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainViewModel {
    MainActivity2 activity;

    public MainViewModel(MainActivity2 activity) {
        this.activity = activity;
    }

    public void setMeetSettingClick() {
        activity.btnMeetSetting.setOnClickListener(view -> {
                    Intent gpsIntent = new Intent(activity, GpsTracker_main.class);
                    gpsIntent.putExtra("mSearchEdit", activity.mSearchEdit.getText().toString());
                    activity.startActivityForResult(gpsIntent, 9999);
                }
        );
    }

    public void setSearchEditClick() {
        activity.mSearchEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean hasFocus) {
                if (hasFocus) {
                } else {
                    activity.recyclerView.setVisibility(View.GONE);

                }
            }
        });
        activity.mSearchEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(activity, "검색리스트에서 장소를 선택해주세요", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void setSearchEditChangeListener() {
        // editText 검색 텍스처이벤트
        activity.mSearchEdit.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
                // 입력하기 전에
                activity.recyclerView.setVisibility(View.VISIBLE);
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                if (charSequence.length() >= 1) {

                    activity.documentArrayList.clear();
                    activity.locationAdapter.clear();
                    activity.locationAdapter.notifyDataSetChanged();
                    ApiInterface apiInterface = ApiClient.getApiClient().create(ApiInterface.class);
                    Call<CategoryResult> call = apiInterface.getSearchLocation(activity.getString(R.string.restapi_key), charSequence.toString(), 15);
                    call.enqueue(new Callback<CategoryResult>() {
                        @Override
                        public void onResponse(Call<CategoryResult> call, Response<CategoryResult> response) {
                            if (response.isSuccessful()) {

                                assert response.body() != null;
                                for (Document document : response.body().getDocuments()) {
                                    activity.locationAdapter.addItem(document);
                                }
                                activity.locationAdapter.notifyDataSetChanged();
                            }
                        }

                        @Override
                        public void onFailure(Call<CategoryResult> call, Throwable t) {

                        }

                    });
                    //}
                    //mLastClickTime = SystemClock.elapsedRealtime();
                } else {
                    if (charSequence.length() <= 0) {
                        activity.recyclerView.setVisibility(View.GONE);
                    }
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });
    }

    public void setOnClickListener() {
        //버튼리스너
        activity.fab.setOnClickListener(activity);
        activity.fab1.setOnClickListener(activity);
        activity.fab2.setOnClickListener(activity);
        activity.fab3.setOnClickListener(activity);
        activity.fab4.setOnClickListener(activity);
        activity.stopTrackingFab.setOnClickListener(activity);
    }

    public void setRecyclerView() {
        activity.locationAdapter = new LocationAdapter(activity.documentArrayList, activity, activity.mSearchEdit, activity.recyclerView);
        LinearLayoutManager layoutManager = new LinearLayoutManager(activity, LinearLayoutManager.VERTICAL, false); //레이아웃매니저 생성
        activity.recyclerView.addItemDecoration(new DividerItemDecoration(activity, DividerItemDecoration.VERTICAL)); //아래구분선 세팅
        activity.recyclerView.setLayoutManager(layoutManager);
        activity.recyclerView.setAdapter(activity.locationAdapter);
    }

    public void setView() {
        activity.mSearchEdit = activity.findViewById(R.id.map_et_search);
        activity.fab_open = AnimationUtils.loadAnimation(activity, R.anim.fab_open);
        activity.fab_close = AnimationUtils.loadAnimation(activity, R.anim.fab_close);
        activity.fab = activity.findViewById(R.id.fab);
        activity.fab1 = activity.findViewById(R.id.fab1);
        activity.fab2 = activity.findViewById(R.id.fab2);
        activity.fab3 = activity.findViewById(R.id.fab3);
        activity.fab4 = activity.findViewById(R.id.fab4);
        activity.btnMeetSetting = activity.findViewById(R.id.btn_meet);
        activity.stopTrackingFab = activity.findViewById(R.id.fab_stop_tracking);
        activity.mLoaderLayout = activity.findViewById(R.id.loaderLayout);
        activity.mMapView = new MapView(activity);
        activity.mMapViewContainer = activity.findViewById(R.id.map_mv_mapcontainer);
        activity.mMapViewContainer.addView(activity.mMapView);
        activity.recyclerView = activity.findViewById(R.id.map_recyclerview);

    }
}
