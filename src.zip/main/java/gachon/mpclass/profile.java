package gachon.mpclass;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import de.hdodenhof.circleimageview.CircleImageView;
import gachon.mpclass.myapplication.R;

import static android.app.Activity.RESULT_OK;


public class profile extends Fragment {

    int count = 0;
    CircleImageView str1;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference UserRef;
    private FirebaseUser cur_user;
    private String name;

    private FirebaseAuth firebaseAuth;

    private ChildEventListener mChild;
    private final int GET_GALLERY_IMAGE = 200;

    Uri imgUri;//선택한 프로필 이미지 경로 Uri

    boolean isFirst = true; //앱을 처음 실행한 것인가?
    boolean isChanged = false; //프로필을 변경한 적이 있는가?

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //프래그먼트 메인을 인플레이트해주고 컨테이너에 붙여달라는 뜻임
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_profile, container, false);

        TextView name = rootView.findViewById(R.id.Name);
        TextView email2 = rootView.findViewById(R.id.Email);
        TextView SM = rootView.findViewById(R.id.statusMessage);
        CircleImageView change_Profile = rootView.findViewById(R.id.image_change);
        CircleImageView Profile_image = str1;
        str1 = rootView.findViewById(R.id.Profile_image);
        Button logout = (Button) rootView.findViewById(R.id.logout_btn);
        Button cha_btn = (Button) rootView.findViewById(R.id.Cha_btn);
        EditText edit_email = rootView.findViewById(R.id.Edit_Email);
        EditText edit_status = rootView.findViewById(R.id.Edit_StatusMessage);
        EditText edit_NickName = rootView.findViewById(R.id.Edit_NickName);

        cur_user = FirebaseAuth.getInstance().getCurrentUser();
        firebaseDatabase = FirebaseDatabase.getInstance();
        UserRef = firebaseDatabase.getReference("Users");

        String email = cur_user.getEmail();
        String key = email.split("@")[0];

        UserRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.child(key).getValue() != null) {
                    String t = snapshot.child(key).child("name").getValue().toString();

                    if(t.length()>20){
                        name.setText(t.substring(22,t.indexOf('}')));
                        edit_NickName.setText(t.substring(22,t.indexOf('}')));
                    }
                    else{
                        name.setText(t);
                        edit_NickName.setText(t);
                    }
                }
                if (snapshot.child(key).child("email").getValue() != null) {
                    String t = snapshot.child(key).child("email").getValue().toString();
                    if(t.length()>20){
                        email2.setText(t.substring(22,t.indexOf('}')));
                        edit_email.setText(t.substring(22,t.indexOf('}')));
                    }
                    else{
                        email2.setText(t);
                        edit_email.setText(t);
                    }
                }

                if(snapshot.child(key).child("Status").getValue() != null){
                    String t = snapshot.child(key).child("Status").getValue().toString();
                    if(t.length()>20){
                        SM.setText(t.substring(22,t.indexOf('}')));
                        edit_status.setText(t.substring(22,t.indexOf('}')));
                    }
                    else{
                        SM.setText(t);
                        edit_status.setText(t);
                    }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                firebaseAuth.signOut();

                name.setText("로그인 해주세요");
                email2.setText("로그인 해주세요");
                SM.setText("로그인 해주세요");
                edit_NickName.setText("로그인 해주세요");
                edit_email.setText("로그인 해주세요");
                edit_status.setText("로그인 해주세요");
                Toast.makeText(getContext(), "로그아웃 되었습니다", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(getContext(), gachon.mpclass.LoginActivity.class);
                startActivity(intent);

            }
        });

        cha_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                for (int i = 0; i < 3; i++) {


                    if (i == 0)

                        UserRef.child(key).child("name").setValue(edit_NickName.getText().toString());
                    else if (i == 1)
                        UserRef.child(key).child("email").setValue(edit_email.getText().toString());
                  else
                      UserRef.child(key).child("Status").setValue(edit_status.getText().toString());
                }

            }
        });

        change_Profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              /*
              Intent intent = new Intent(Intent.ACTION_PICK);
              intent.setDataAndType(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,"image/*");
                startActivityForResult(intent,GET_GALLERY_IMAGE);*/
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, 10);
                saveData();
            }

        });


        return rootView;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable @org.jetbrains.annotations.Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case 10:
                if (resultCode == RESULT_OK) {
                    imgUri = data.getData();
                    //Glide.with(this).load(imgUri).into(ivProfile);
                    //Glide는 이미지를 읽어와서 보여줄때 내 device의 외장메모리에 접근하는 퍼미션이 요구됨.
                    //(퍼미션이 없으면 이미지가 보이지 않음.)
                    //Glide를 사용할 때는 동적 퍼미션 필요함.

                    //Picasso 라이브러리는 퍼미션 없어도 됨.
                    Picasso.get().load(imgUri).into(str1);

                    //변경된 이미지가 있다.
                    isChanged = true;
                }
                break;
        }
    }

    void saveData(){
        //EditText의 닉네임 가져오기 [전역변수에]

        //이미지를 선택하지 않았을 수도 있으므로
        if(imgUri==null) return;

        //Firebase storage에 이미지 저장하기 위해 파일명 만들기(날짜를 기반으로)
        SimpleDateFormat sdf= new SimpleDateFormat("yyyMMddhhmmss"); //20191024111224
        String fileName= sdf.format(new Date())+".png";

        //Firebase storage에 저장하기
        FirebaseStorage firebaseStorage= FirebaseStorage.getInstance();
        final StorageReference imgRef= firebaseStorage.getReference("profileImages/"+fileName);

        //파일 업로드
        UploadTask uploadTask=imgRef.putFile(imgUri);
        uploadTask.addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
            @Override
            public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                //이미지 업로드가 성공되었으므로...
                //곧바로 firebase storage의 이미지 파일 다운로드 URL을 얻어오기
                imgRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                    @Override
                    public void onSuccess(Uri uri) {
                        //파라미터로 firebase의 저장소에 저장되어 있는
                        //이미지에 대한 다운로드 주소(URL)을 문자열로 얻어오기
                        gachon.mpclass.G.porfileUrl= uri.toString();
                        Toast.makeText(getContext(), "프로필 저장 완료", Toast.LENGTH_SHORT).show();

                        //1. Firebase Database에 nickName, profileUrl을 저장
                        //firebase DB관리자 객체 소환
                        FirebaseDatabase firebaseDatabase=FirebaseDatabase.getInstance();
                        //'profiles'라는 이름의 자식 노드 참조 객체 얻어오기
                        DatabaseReference profileRef= firebaseDatabase.getReference("profiles");

                        //닉네임을 key 식별자로 하고 프로필 이미지의 주소를 값으로 저장
                        profileRef.child(gachon.mpclass.G.nickName).setValue(gachon.mpclass.G.porfileUrl);
                    }
                });
            }
        });
    }

    private void getFireBaseProfileImage(int num){
        File file =getActivity().getExternalFilesDir(Environment.DIRECTORY_PICTURES + "/profile_img");
        if(!file.isDirectory()){
            file.mkdir();
        }
        downloadimg(num);
    }

    private void downloadimg(int num){
        FirebaseStorage storage = FirebaseStorage.getInstance();
        StorageReference storageRef = storage.getReference();

        storageRef.child("profile_img/" + "profile" + num + ".jpg").getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri uri) {

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull @NotNull Exception e) {

            }
        });
    }
}