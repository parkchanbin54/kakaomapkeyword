package gachon.mpclass;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import gachon.mpclass.myapplication.R;

// 회원가입 화면에서 진행될 작동구조
// 필요한 xml : activity_register
// 필요한 id resource : emailEt, passwordEdt, passwordcheckEdt, register2_btn, nameEt
public class RegisterActivity extends AppCompatActivity {

    private static final String TAG = "RegisterActivity";
    EditText mEmailText, mPasswordText, mPasswordcheckText, mName;
    Button mregisterBtn;
    private FirebaseAuth firebaseAuth;
    private FirebaseDatabase database = FirebaseDatabase.getInstance();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        //액션 바 등록하기
        //상단 제목 이름 Create Account


        //파이어베이스 접근 설정, 권한 갖기
        firebaseAuth = FirebaseAuth.getInstance();

        mEmailText = findViewById(R.id.mail); // email text
        mPasswordText = findViewById(R.id.password); // password text
        mPasswordcheckText = findViewById(R.id.passwordCheck); // 한번 더 입력
        mregisterBtn = findViewById(R.id.RegisterBtn); // 등록하기 버튼
        mName = findViewById(R.id.name); // 이름 text

        //파이어베이스 user 로 접근
        //FirebaseUser user = firebaseAuth.getCurrentUser();

        //가입버튼 클릭리스너   -->  firebase에 데이터를 저장한다.
        mregisterBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //가입 정보 가져오기
                //trim 공백 없애기
                String email = mEmailText.getText().toString().trim();
                String pwd = mPasswordText.getText().toString().trim();
                String pwdcheck = mPasswordcheckText.getText().toString().trim();

                //passward 와 passwardcheck 가 같을 경우, 다를 경우
                if (pwd.equals(pwdcheck)) {
                    //Log.d(TAG, "등록 버튼 " + email + " , " + pwd);
                    ProgressDialog mDialog = new ProgressDialog(RegisterActivity.this);
                    Toast.makeText(RegisterActivity.this, "가입중입니다...", Toast.LENGTH_SHORT).show();

                    //파이어베이스에 신규계정 등록하기
                    firebaseAuth.createUserWithEmailAndPassword(email, pwd)
                            .addOnCompleteListener
                                    (RegisterActivity.this, new OnCompleteListener<AuthResult>() {
                                        @Override
                                        public void onComplete(@NonNull Task<AuthResult> task) {
                                            //가입 성공시
                                            if (task.isSuccessful()) {
                                                ;


                                                mDialog.dismiss();

                                                FirebaseUser user = firebaseAuth.getCurrentUser();
                                                String email = user.getEmail();
                                                String key = email.split("@")[0];
                                                String name = mName.getText().toString().trim();

                                                database = FirebaseDatabase.getInstance();
                                                DatabaseReference reference = database.getReference("Users");
                                                reference.child(key).child("email").setValue(email);
                                                reference.child(key).child("name").setValue(name);
                                                //해쉬맵 테이블을 파이어베이스 데이터베이스에 저장
                                                //해쉬맵 테이블은 다른 테이블 개념과 같음.

                                                //가입이 이루어졌을 시 로그인 화면으로 전환.
                                                Intent intent = new Intent(RegisterActivity.this, gachon.mpclass.LoginActivity.class);
                                                startActivity(intent);
                                                finish();
                                                Toast.makeText(RegisterActivity.this, "회원가입에 성공하셨습니다.", Toast.LENGTH_SHORT).show();

                                                //이미 가입되어 있는 경우
                                            } else {
                                                mDialog.dismiss();
                                                Toast.makeText(RegisterActivity.this, "이미 존재하는 아이디 입니다.", Toast.LENGTH_SHORT).show();
                                                return;  //해당 메소드 진행을 멈추고 빠져나감.
                                            }
                                        }
                                    });

                    //비밀번호 오류 passward 와 passwardcheck 가 다를경우
                } else {
                    Toast.makeText(RegisterActivity.this, "비밀번호가 틀렸습니다. 다시 입력해 주세요.", Toast.LENGTH_SHORT).show();
                    return;
                }
            }
        });

    }

    public boolean onSupportNavigateUp() {
        onBackPressed();
        ; // 뒤로가기 버튼이 눌렸을시
        return super.onSupportNavigateUp(); // 뒤로가기 버튼
    }
}
