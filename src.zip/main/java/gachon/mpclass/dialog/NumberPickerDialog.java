package gachon.mpclass.dialog;

import android.app.Dialog;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.ColorDrawable;
import android.os.Build;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.NumberPicker;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import java.lang.reflect.Field;

import gachon.mpclass.myapplication.R;


public class NumberPickerDialog extends DialogFragment implements View.OnClickListener {


    //showUnitDialog
    private static final String TAG = "NumberPickerDialog";
    private Button mSetBtn;
    private NumberPicker mNumPicker;
    private NumberPickerDialogListener mListener;

    private int mMin;
    private int mMax;
    private int mValue;

    private static NumberPickerDialog dialogFragment;

    @Override
    public void onPause() {
        super.onPause();
        if (dialogFragment != null && dialogFragment.isVisible()) {
            dialogFragment.dismiss();
        }

    }

    public static NumberPickerDialog showNumberPickerDialog(NumberPickerDialogListener listener, FragmentManager fm, int min, int max, int value) {
        dialogFragment = new NumberPickerDialog();
        dialogFragment.setListener(listener);
        dialogFragment.setMin(min);
        dialogFragment.setMax(max);
        dialogFragment.setValue(value);
        FragmentTransaction ft = fm.beginTransaction();
        ft.add(dialogFragment, TAG);
        ft.commitAllowingStateLoss();

        return dialogFragment;
    }


    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        return super.onCreateDialog(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getDialog().getWindow().requestFeature(Window.FEATURE_NO_TITLE);
        View view = inflater.inflate(R.layout.number_picker_dialog, container);

        mSetBtn = (Button) view.findViewById(R.id.set_btn);

        mNumPicker = (NumberPicker) view.findViewById(R.id.numpicker);


        mSetBtn.setOnClickListener(this);


        mNumPicker.setOnClickListener(this);
        mNumPicker.setTag(0);


        setValueRange(mNumPicker, mMin, mMax, mValue);
        setDividerColor(mNumPicker, Color.TRANSPARENT);
        setTextColor(mNumPicker, Color.WHITE);


        mNumPicker.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);

        mNumPicker.setLayoutParams(new NumberPicker.LayoutParams(NumberPicker.LayoutParams.WRAP_CONTENT, NumberPicker.LayoutParams.WRAP_CONTENT));
        setNumberPickerColor();

        return view;
    }

    private void setNumberPickerColor() {
        setTextColor(mNumPicker, Color.argb(255, 0, 0, 0));
    }

    private void setTextSize(NumberPicker numberPicker, float textsize) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            final int count = numberPicker.getChildCount();
            for (int i = 0; i < count; i++) {
                View child = numberPicker.getChildAt(i);
                if (child instanceof EditText) {
                    try {
                        Field selectorWheelPaintField = numberPicker.getClass()
                                .getDeclaredField("mSelectorWheelPaint");
                        selectorWheelPaintField.setAccessible(true);
                        ((Paint) selectorWheelPaintField.get(numberPicker)).setTextSize(textsize);
                        ((EditText) child).setTextSize(21f);
                        numberPicker.invalidate();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {
            numberPicker.setTextSize(textsize);
        }


    }

    private void setTextColor(NumberPicker numberPicker, int color) {

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            final int count = numberPicker.getChildCount();
            for (int i = 0; i < count; i++) {
                View child = numberPicker.getChildAt(i);
                if (child instanceof EditText) {
                    try {
                        Field selectorWheelPaintField = numberPicker.getClass().getDeclaredField("mSelectorWheelPaint");
                        selectorWheelPaintField.setAccessible(true);
                        ((Paint) selectorWheelPaintField.get(numberPicker)).setColor(color);
                        ((EditText) child).setTextColor(color);
                        ((EditText) child).setInputType(InputType.TYPE_CLASS_NUMBER);
                        numberPicker.invalidate();
                    } catch (NoSuchFieldException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    }
                }
            }
        } else {
            numberPicker.setTextColor(color);
        }

    }

    private void setValueRange(NumberPicker view, int min, int max, int val) {
        if (view != null) {
            view.setMinValue(min);
            view.setMaxValue(max);
            view.setValue(val);
        }
    }

    private void setDividerColor(NumberPicker picker, int color) {
        Field[] pickerFields = NumberPicker.class.getDeclaredFields();

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            for (Field pf : pickerFields) {
                if (pf.getName().equals("mSelectionDivider")) {
                    pf.setAccessible(true);

                    try {
                        ColorDrawable colorDrawable = new ColorDrawable(color);
                        pf.set(picker, colorDrawable);

                    } catch (IllegalArgumentException e) {
                        e.printStackTrace();
                    } catch (Resources.NotFoundException e) {
                        e.printStackTrace();
                    } catch (IllegalAccessException e) {
                        e.printStackTrace();
                    }
                    break;
                }
            }
        } else {
            picker.setSelectionDividerHeight(0);
        }
    }

    @Override
    public void onClick(View v) {
        if (v.equals(mSetBtn)) {

            String[] mNumPickerDisplayedValues = mNumPicker.getDisplayedValues();
            String val;
            String val2 = null;

            if (mNumPickerDisplayedValues != null) {
                val = mNumPickerDisplayedValues[mNumPicker.getValue() - 1];
            } else {
                val = String.valueOf(mNumPicker.getValue());
            }
            mListener.onNumberPickerValue(val);
            dismiss();

        }
    }

    public NumberPickerDialogListener getListener() {
        return mListener;
    }

    public void setListener(NumberPickerDialogListener Listener) {
        this.mListener = Listener;
    }


    public void setMin(int Min) {
        this.mMin = Min;
    }

    public void setMax(int Max) {
        this.mMax = Max;
    }

    public void setValue(int Value) {
        this.mValue = Value;
    }

    public interface NumberPickerDialogListener {
        public void onNumberPickerValue(String value);
    }
}
