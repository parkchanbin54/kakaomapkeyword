package gachon.mpclass;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

import gachon.mpclass.adapter.ChatlistgAdapter;
import gachon.mpclass.myapplication.R;


public class talk extends Fragment {
    ChatlistgAdapter writtingAdapter;
    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference myRef = FirebaseDatabase.getInstance().getReference();

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //프래그먼트 메인을 인플레이트해주고 컨테이너에 붙여달라는 뜻임
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_talk, container, false);
        RecyclerView rcv;
        LinearLayoutManager llm;

        /*Adapter myAdapter;*/

        rcv = (RecyclerView) rootView.findViewById(R.id.listview);
        llm = new LinearLayoutManager(getContext());

        rcv.setHasFixedSize(true);
        rcv.setLayoutManager(llm);
        ArrayList<gachon.mpclass.chatlist> list = new ArrayList<>();

        list.add(new gachon.mpclass.chatlist("TestUser1", R.drawable.icon, "테스트 입니다"));
        list.add(new gachon.mpclass.chatlist("TestUser2", R.drawable.ic_launcher_background, "테스트 입니다"));
        list.add(new gachon.mpclass.chatlist("TestUser3", R.drawable.icon11, "테스트 일까나?"));
        list.add(new gachon.mpclass.chatlist("TestUser4", R.drawable.back_et_mymsgbox, "테스트 하는중"));
        list.add(new gachon.mpclass.chatlist("TestUser5", R.drawable.camera123, "테스트 이예"));

        //rcv.setAdapter(myAdapter);
        writtingAdapter = new ChatlistgAdapter(getActivity(), list);
        rcv.setAdapter(writtingAdapter);

        return rootView;
    }
}