package gachon.mpclass;

public class G {

    public static String nickName;
    public static String porfileUrl;
}