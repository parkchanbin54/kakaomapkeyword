package gachon.mpclass;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.fragment.app.Fragment;

import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import gachon.mpclass.myapplication.R;


public class Carlendar extends Fragment {
    String str = null, name=null;
    int filen=0 , filen2=0, count=0;

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference myRef = FirebaseDatabase.getInstance().getReference();
    private ChildEventListener mChild;

    public Carlendar(){

    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        //프래그먼트 메인을 인플레이트해주고 컨테이너에 붙여달라는 뜻임
        ViewGroup rootView = (ViewGroup) inflater.inflate(R.layout.fragment_calender, container, false);

        CalendarView calendar = rootView.findViewById(R.id.calendarView);
        TextView diaryTextView = rootView.findViewById(R.id.diaryTextView);
        Button save_btn = rootView.findViewById(R.id.save_Btn);
        Button del_btn = rootView.findViewById(R.id.del_Btn);
        Button cha_btn = rootView.findViewById(R.id.cha_Btn);
        TextView textView2 = rootView.findViewById(R.id.textView2);
        ConstraintLayout constraintLayout = rootView.findViewById(R.id.invisible_thing);
        EditText context = rootView.findViewById(R.id.contextEditText);


        calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @SuppressLint("WrongConstant")
            public void onSelectedDayChange(CalendarView view, int year,
                                            int month, int dayOfMonth) {
                constraintLayout.setVisibility(View.VISIBLE);
                diaryTextView.setVisibility(View.VISIBLE);
                diaryTextView.setText(year + "/" + (month+1) + "/" + dayOfMonth);
                context.setVisibility(View.VISIBLE);
                textView2.setVisibility(View.INVISIBLE);
                save_btn.setVisibility(View.VISIBLE);
                cha_btn.setVisibility(View.INVISIBLE);
                del_btn.setVisibility(View.INVISIBLE);
                filen=month+1;
                filen2=dayOfMonth;
                context.setText("");
                initDatabase();

                myRef.child("message").child("message"+filen+filen2).addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.getValue()!= null){
                            String game = snapshot.getValue().toString();
                            name= game.substring(22, game.indexOf('}')) ;
                            textView2.setVisibility(View.VISIBLE);
                            context.setVisibility(View.INVISIBLE);
                            textView2.setText(name);
                            save_btn.setVisibility(View.INVISIBLE);
                            cha_btn.setVisibility(View.VISIBLE);
                            del_btn.setVisibility(View.VISIBLE);
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });


            }
        });


        save_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context.setVisibility(View.INVISIBLE);
                textView2.setVisibility(View.VISIBLE);
                str = context.getText().toString();
                textView2.setText(str);
                save_btn.setVisibility(View.INVISIBLE);
                cha_btn.setVisibility(View.VISIBLE);
                del_btn.setVisibility(View.VISIBLE);
                delete();
                myRef.child("message").child("message"+filen+filen2).push().setValue(str);
            }
        });
        cha_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                context.setVisibility(View.VISIBLE);
                textView2.setVisibility(View.INVISIBLE);
                context.setText(name);
                save_btn.setVisibility(View.VISIBLE);
                cha_btn.setVisibility(View.INVISIBLE);
                del_btn.setVisibility(View.INVISIBLE);
                textView2.setText(context.getText());
            }
        });
        del_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                textView2.setVisibility(View.INVISIBLE);
                context.setText("");
                context.setVisibility(View.VISIBLE);
                save_btn.setVisibility(View.VISIBLE);
                cha_btn.setVisibility(View.INVISIBLE);
                del_btn.setVisibility(View.INVISIBLE);
                delete();
            }
        });


        return rootView;
    }


    public void delete(){
        myRef = database.getReference();
        myRef.child("message").child("message"+filen+filen2).setValue(null);
                }

    private void initDatabase() {

       database = FirebaseDatabase.getInstance();

        myRef =database.getReference();


        mChild = new ChildEventListener() {

            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        };
       myRef.addChildEventListener(mChild);
    }



    }
