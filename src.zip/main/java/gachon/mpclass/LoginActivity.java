package gachon.mpclass;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import gachon.mpclass.myapplication.R;

//로그인 화면에서 진행될 작동구조
//로그인 버튼이 눌렸을 시 BottomNaviActivity?? ??
//intent 이벤트를 통해 BottomNaviActivity.class 의 페이지로 이동한다 >> start(intent)
//필요한 xml : activity_login
//필요한 id resource : register_t2, login_btn, emailEt, passwordEdt
public class LoginActivity extends AppCompatActivity {

    Button mLoginBtn;
    TextView mResibtn;
    EditText mEmailText, mPasswordText;
    private FirebaseAuth firebaseAuth;
    private long backKeyPressedTime = 0;
    private Toast toast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        FirebaseApp.initializeApp(getApplicationContext());
        firebaseAuth = FirebaseAuth.getInstance();

        //버튼 등록하기
        mResibtn = findViewById(R.id.register); // 가입하기 버튼
        mLoginBtn = (Button) findViewById(R.id.login); // 로그인 버튼
        mEmailText = findViewById(R.id.username); // email text
        mPasswordText = findViewById(R.id.password); // password text


        //가입 버튼이 눌리면
        mResibtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                //intent함수를 통해 register 액티비티 함수를 호출한다.
                startActivity(new Intent(getApplicationContext(), RegisterActivity.class));

            }
        });

        //로그인 버튼이 눌리면
        mLoginBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String email = mEmailText.getText().toString().trim();
                String pwd = mPasswordText.getText().toString().trim();

                if (email.equals("") || pwd.equals("")) {
                    Toast.makeText(LoginActivity.this, "로그인 오류", Toast.LENGTH_SHORT).show();
                }
                try {
                    //파이어베이스에 등록되어 있는 계정인지 확인
                    firebaseAuth.signInWithEmailAndPassword(email, pwd)
                            .addOnCompleteListener(LoginActivity.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    //로그인 되면 다음 화면으로 넘어가짐
                                    //그 화면이 나타나는 class 가 BottomNaviActivity
                                    if (task.isSuccessful()) {

                                        Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                                        startActivity(intent);

                                        //파이어베이스에 없는 계정이면
                                    } else {
                                        Toast.makeText(LoginActivity.this, "로그인 오류", Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                } catch (Exception e) {
                    Toast.makeText(LoginActivity.this, "로그인 오류", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

    @Override
    public void onBackPressed() {
        //super.onBackPressed();
        if (System.currentTimeMillis() > backKeyPressedTime + 2500) {
            backKeyPressedTime = System.currentTimeMillis();
            toast = Toast.makeText(this, "뒤로 가기 버튼을 한 번 더 누르시면 종료됩니다.", Toast.LENGTH_LONG);
            toast.show();
            return;
        }
        if (System.currentTimeMillis() <= backKeyPressedTime + 2500) {
            System.exit(0);
            toast.cancel();
            toast = Toast.makeText(this,"이용해 주셔서 감사합니다.",Toast.LENGTH_LONG);
            toast.show();
        }
    }
}
